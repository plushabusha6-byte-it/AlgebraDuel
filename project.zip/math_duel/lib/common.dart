import 'package:flutter/material.dart';

String mmss(int sec) {
  final m = sec ~/ 60;
  final s = sec % 60;
  return '$m:${s.toString().padLeft(2, '0')}';
}

/// Общая «рамка» экрана: прокрутка, ограничение ширины, отступы.
class Shell extends StatelessWidget {
  final Widget child;
  final String? title;
  const Shell({super.key, required this.child, this.title});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: title == null ? null : AppBar(title: Text(title!), centerTitle: true),
      body: SafeArea(
        child: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 560),
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(16),
              child: child,
            ),
          ),
        ),
      ),
    );
  }
}

void snack(BuildContext context, String text) {
  ScaffoldMessenger.of(context)
    ..hideCurrentSnackBar()
    ..showSnackBar(SnackBar(content: Text(text)));
}

/// Нумерованное решение по шагам.
class StepsList extends StatelessWidget {
  final List<String> steps;
  const StepsList({super.key, required this.steps});

  @override
  Widget build(BuildContext context) {
    final th = Theme.of(context);
    if (steps.isEmpty) {
      return const Text('Подробного решения для этого примера нет.');
    }
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        for (var i = 0; i < steps.length; i++)
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 4),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                CircleAvatar(
                  radius: 12,
                  child: Text('${i + 1}', style: const TextStyle(fontSize: 12)),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: Text(steps[i],
                      style: th.textTheme.bodyLarge?.copyWith(height: 1.4)),
                ),
              ],
            ),
          ),
      ],
    );
  }
}
