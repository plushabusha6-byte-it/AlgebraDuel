import 'dart:math';

/// Одна задача: уравнение (или система), правильный ответ и две подсказки.
class Task {
  final String topic;
  final String text;
  final String instruction;
  final List<double> answer;
  final String answerText;
  final List<String> hints;

  /// true — порядок ответов важен (для систем: сначала x, потом y).
  final bool ordered;

  const Task({
    required this.topic,
    required this.text,
    required this.instruction,
    required this.answer,
    required this.answerText,
    this.hints = const [],
    this.ordered = false,
  });
}

const levelNames = ['5–6 класс', '7–8 класс', '9 класс', '10–11 класс'];
const levelShort = ['5–6', '7–8', '9', '10–11'];
const levelTopics = [
  'Линейные уравнения со скобками и дробями',
  'Скобки, дроби, модуль, неполные квадратные, системы',
  'Квадратные, биквадратные и дробные уравнения',
  'Кубические, показательные, логарифмические, иррациональные',
];

/// Время на пример по умолчанию (минуты) для каждого уровня.
const defaultMinutes = [3, 4, 5, 6];

/// Сколько подсказок доступно на один пример.
const hintsPerRound = 2;

final Random _rnd = Random();

int _ri(int a, int b) => a + _rnd.nextInt(b - a + 1);

int _nz(int a, int b) {
  var v = 0;
  while (v == 0) {
    v = _ri(a, b);
  }
  return v;
}

T _pick<T>(List<T> l) => l[_rnd.nextInt(l.length)];

int _lcm(int a, int b) => a ~/ a.gcd(b) * b;

int _isqrt(int d) => sqrt(d).round();

// ---------- Форматирование ----------

/// Целое число с красивым минусом.
String _n(int v) => v < 0 ? '−${-v}' : '$v';

/// Многочлен/линейное выражение: список (коэффициент, переменная).
String _expr(List<(int, String)> ts) {
  final sb = StringBuffer();
  var first = true;
  for (final t in ts) {
    final c = t.$1;
    final v = t.$2;
    if (c == 0) continue;
    final m = c.abs();
    final body = v.isEmpty ? '$m' : (m == 1 ? v : '$m$v');
    if (first) {
      sb.write(c < 0 ? '−$body' : body);
      first = false;
    } else {
      sb.write(c < 0 ? ' − $body' : ' + $body');
    }
  }
  return first ? '0' : sb.toString();
}

String _sgn(int n) => n < 0 ? '− ${-n}' : '+ $n';

/// "x + 3", "x − 3" или просто "x".
String _xs(int a) => a == 0 ? 'x' : 'x ${_sgn(a)}';

/// "(x + 3)/4" или "x/4".
String _over(int a, int d) => a == 0 ? 'x/$d' : '(${_xs(a)})/$d';

String _d10(int v) =>
    v % 10 == 0 ? '${v ~/ 10}' : (v / 10).toStringAsFixed(1).replaceAll('.', ',');

String _num(num n) {
  final d = n.toDouble();
  final s = d == d.roundToDouble() ? d.toInt().toString() : d.toString();
  return s.replaceFirst('-', '−');
}

String _frac(int n, int d) {
  final g = n.gcd(d);
  var nn = n ~/ g;
  var dd = d ~/ g;
  if (dd < 0) {
    nn = -nn;
    dd = -dd;
  }
  return dd == 1 ? _num(nn) : '${_num(nn)}/$dd';
}

List<double> _uniqSorted(Iterable<num> xs) {
  final l = xs.map((e) => e.toDouble()).toList()..sort();
  final out = <double>[];
  for (final v in l) {
    if (out.isEmpty || (v - out.last).abs() > 1e-9) out.add(v);
  }
  return out;
}

// ---------- Построители задач с самопроверкой ----------

const List<String> _defaultHints = [
  'Упрощайте уравнение шаг за шагом: раскройте скобки и соберите x в одной части.',
  'Найдя ответ, проверьте его подстановкой в исходное уравнение.',
];

/// Задача с корнями [roots]. Корни подставляются в [f] (левая часть минус правая),
/// и если хоть один не даёт 0 — задача отбрасывается (защита от ошибок в алгебре).
Task? _roots(
  String topic,
  String text,
  List<num> roots,
  double Function(double) f, {
  String? instruction,
  String? answerText,
  List<String>? hints,
}) {
  final r = _uniqSorted(roots);
  if (r.isEmpty) return null;
  for (final v in r) {
    final y = f(v);
    if (y.isNaN || y.isInfinite || y.abs() > 1e-7) return null;
  }
  return Task(
    topic: topic,
    text: text,
    instruction: instruction ??
        (r.length > 1
            ? 'Найдите все корни. Если их несколько — запишите через пробел.'
            : 'Найдите x.'),
    answer: r,
    answerText: answerText ?? r.map(_num).join(';  '),
    hints: hints ?? _defaultHints,
  );
}

// ---------- 5–6 класс ----------

Task? _g56a() {
  final x = _ri(1, 15), a = _ri(1, 9), b = _ri(2, 9);
  final c = _ri(1, (x + a) * b - 1);
  final d = (x + a) * b - c;
  return _roots(
    'Линейное уравнение',
    '(x + $a) · $b − $c = $d',
    [x],
    (t) => (t + a) * b - c - d,
    hints: [
      'Неизвестное спрятано в скобках. Сначала найдите, чему равно (x + $a) · $b: к $d прибавьте $c.',
      '(x + $a) · $b = ${d + c}. Разделите ${d + c} на $b — так вы узнаете, чему равна сумма x + $a.',
    ],
  );
}

Task? _g56b() {
  final x = _ri(1, 15), c = _ri(1, 5), a = c + _ri(2, 7), b = _ri(1, 20);
  final d = (a - c) * x + b;
  final cx = c == 1 ? 'x' : '${c}x';
  return _roots(
    'Неизвестное в обеих частях',
    '${_expr([(a, 'x'), (b, '')])} = ${_expr([(c, 'x'), (d, '')])}',
    [x],
    (t) => a * t + b - (c * t + d),
    hints: [
      'Соберите все x слева, а числа справа: вычтите $cx и $b из обеих частей уравнения.',
      'Получится ${a - c}x = ${d - b}. Осталось разделить ${d - b} на ${a - c}.',
    ],
  );
}

Task? _g56c() {
  final a = _ri(2, 9), k = _ri(2, 12), b = _ri(1, 15);
  final x = a * k, c = k + b;
  return _roots(
    'Деление и сложение',
    'x : $a + $b = $c',
    [x],
    (t) => t / a + b - c,
    hints: [
      'Сначала найдите, чему равно x : $a — для этого вычтите $b из $c.',
      'x : $a = ${c - b}. Чтобы найти x, умножьте ${c - b} на $a.',
    ],
  );
}

Task? _g56d() {
  const as10 = [5, 15, 25, 2, 4, 6, 8, 12, 35];
  final a10 = _pick(as10), x = _ri(1, 12), b10 = _ri(1, 30);
  final c10 = a10 * x + b10;
  return _roots(
    'Десятичные дроби',
    '${_d10(a10)}x + ${_d10(b10)} = ${_d10(c10)}',
    [x],
    (t) => a10 / 10 * t + b10 / 10 - c10 / 10,
    hints: [
      'Вычтите ${_d10(b10)} из обеих частей, затем разделите на ${_d10(a10)}.',
      '${_d10(a10)}x = ${_d10(c10 - b10)}. Осталось разделить ${_d10(c10 - b10)} на ${_d10(a10)}.',
    ],
  );
}

Task? _g56e() {
  final x = _ri(3, 12), a = _ri(2, 9), c = _ri(2, 6), d = _ri(2, 9);
  final b = a * x - c * d;
  if (b < 1) return null;
  return _roots(
    'Скобки и деление',
    '(${a}x − $b) : $c = $d',
    [x],
    (t) => (a * t - b) / c - d,
    hints: [
      'Сначала найдите, чему равно выражение в скобках: умножьте $d на $c.',
      '${a}x − $b = ${c * d}. Значит, ${a}x = ${c * d + b}.',
    ],
  );
}

// ---------- 7–8 класс ----------

Task? _g78a() {
  final p = _ri(2, 7), q = _ri(2, 7), a = _nz(-6, 9), b = _nz(-6, 9);
  final r = _ri(-3, 5), x0 = _ri(-8, 10);
  if ((p - q - r).abs() < 2) return null;
  final k = p * a - q * b;
  final s = (p - q - r) * x0 + k;
  final lhs = '$p(${_xs(a)}) − $q(${_xs(b)})';
  return _roots(
    'Скобки с обеих сторон',
    '$lhs = ${_expr([(r, 'x'), (s, '')])}',
    [x0],
    (t) => p * (t + a) - q * (t + b) - (r * t + s),
    hints: [
      'Раскройте скобки (помните про минус перед второй скобкой) и приведите подобные слагаемые.',
      'Слева получится ${_expr([(p - q, 'x'), (k, '')])}. После переноса членов с x влево: ${_expr([(p - q - r, 'x')])} = ${_n(s - k)}.',
    ],
  );
}

Task? _g78b() {
  final b = _ri(2, 6), d = _ri(2, 6), k1 = _ri(-4, 6), k2 = _ri(-4, 6);
  final x0 = _ri(-9, 12);
  final a = b * k1 - x0, c = d * k2 - x0;
  final l = _lcm(b, d);
  return _roots(
    'Дробное уравнение',
    '${_over(a, b)} + ${_over(c, d)} = ${_n(k1 + k2)}',
    [x0],
    (t) => (t + a) / b + (t + c) / d - (k1 + k2),
    hints: [
      b == d
          ? 'Умножьте обе части на $b — так уйдут знаменатели.'
          : 'Умножьте обе части на общий знаменатель — число, которое делится и на $b, и на $d.',
      'Умножьте на $l: получится ${l ~/ b}·(${_xs(a)}) + ${l ~/ d}·(${_xs(c)}) = ${_n(l * (k1 + k2))}.',
    ],
  );
}

Task? _g78c() {
  final a1 = _nz(-5, 5), b1 = _nz(-5, 5), a2 = _nz(-5, 5), b2 = _nz(-5, 5);
  if (a1 * b2 - a2 * b1 == 0) return null;
  final x0 = _ri(-6, 8), y0 = _ri(-6, 8);
  final c1 = a1 * x0 + b1 * y0, c2 = a2 * x0 + b2 * y0;
  // Проверка: после исключения x должно получиться верное уравнение для y.
  if ((b1 * a2 - b2 * a1) * y0 != c1 * a2 - c2 * a1) return null;
  return Task(
    topic: 'Система уравнений',
    text: '${_expr([(a1, 'x'), (b1, 'y')])} = ${_n(c1)}\n'
        '${_expr([(a2, 'x'), (b2, 'y')])} = ${_n(c2)}',
    instruction:
        'Решите систему. Запишите ответ: сначала x, потом y, через пробел.',
    answer: [x0.toDouble(), y0.toDouble()],
    answerText: 'x = ${_n(x0)};  y = ${_n(y0)}',
    ordered: true,
    hints: [
      'Уравняйте коэффициенты при x (или при y), затем сложите или вычтите уравнения — останется одно неизвестное.',
      'Умножьте первое уравнение на ${_n(a2)}, второе — на ${_n(a1)} и вычтите из первого уравнения второе. Получится ${_expr([(b1 * a2 - b2 * a1, 'y')])} = ${_n(c1 * a2 - c2 * a1)}.',
    ],
  );
}

Task? _g78d() {
  final a = _ri(-6, 8), b = _ri(1, 9);
  return _roots(
    'Уравнение с модулем',
    '|${_xs(-a)}| = $b',
    [a - b, a + b],
    (t) => (t - a).abs() - b,
    hints: [
      'Модуль равен $b, значит выражение внутри модуля равно $b или −$b.',
      'Решите два уравнения: ${_xs(-a)} = $b и ${_xs(-a)} = −$b.',
    ],
  );
}

Task? _g78e() {
  final n = _ri(2, 9), a = _ri(2, 5);
  final cc = -a * n * n;
  return _roots(
    'Неполное квадратное',
    '${_expr([(a, 'x²'), (cc, '')])} = 0',
    [n, -n],
    (t) => a * t * t + cc,
    hints: [
      'Перенесите число в правую часть и разделите обе части на $a.',
      'x² = ${n * n}. Подумайте: какие числа в квадрате дают ${n * n}? Их два.',
    ],
  );
}

// ---------- 9 класс ----------

Task? _g9a() {
  final a = _pick([1, 1, 2, 3]), u = _nz(-9, 9), v = _nz(-9, 9);
  if (u == v) return null;
  final cb = -a * (u + v), cc = a * u * v;
  final dd = cb * cb - 4 * a * cc;
  return _roots(
    'Квадратное уравнение',
    '${_expr([(a, 'x²'), (cb, 'x'), (cc, '')])} = 0',
    [u, v],
    (t) => a * t * t + cb * t + cc,
    hints: [
      'Найдите дискриминант D = b² − 4ac, где a, b, c — коэффициенты уравнения.',
      'D = $dd, √D = ${_isqrt(dd)}. Дальше: x = (−b ± √D) : (2a).',
    ],
  );
}

Task? _g9b() {
  final p = _nz(-6, 6), q = _nz(-6, 6), u = _ri(-8, 8), v = _ri(-8, 8);
  if (u == v) return null;
  final k = p + q + u + v, m = p * q - u * v;
  return _roots(
    'Квадратное уравнение со скобками',
    '(${_xs(p)})(${_xs(q)}) = ${_expr([(k, 'x'), (m, '')])}',
    [u, v],
    (t) => (t + p) * (t + q) - (k * t + m),
    hints: [
      'Раскройте скобки и перенесите всё в левую часть — получится обычное квадратное уравнение.',
      'Получится: ${_expr([(1, 'x²'), (p + q - k, 'x'), (p * q - m, '')])} = 0. Решите его.',
    ],
  );
}

Task? _g9c() {
  final p = _pick([-9, -7, -5, -3, -1, 1, 3, 5, 7, 9]), q = _nz(-6, 6);
  final cb = 2 * q - p, cc = -p * q;
  final dd = cb * cb - 8 * cc;
  return _roots(
    'Квадратное уравнение с дробным корнем',
    '${_expr([(2, 'x²'), (cb, 'x'), (cc, '')])} = 0',
    [p / 2, -q],
    (t) => 2 * t * t + cb * t + cc,
    instruction:
        'Найдите все корни через пробел. Дробь можно записать так: 3/2 или 1,5.',
    answerText: '${_frac(p, 2)};  ${_num(-q)}',
    hints: [
      'Найдите дискриминант D = b² − 4ac, где a, b, c — коэффициенты уравнения.',
      'D = $dd, √D = ${_isqrt(dd)}. Корни: x = (−b ± √D) : 4.',
    ],
  );
}

Task? _g9d() {
  final u = _ri(1, 5), v = _ri(1, 5);
  if (u == v) return null;
  final s = u * u + v * v, pr = u * u * v * v;
  return _roots(
    'Биквадратное уравнение',
    '${_expr([(1, 'x⁴'), (-s, 'x²'), (pr, '')])} = 0',
    [u, -u, v, -v],
    (t) => t * t * t * t - s * t * t + pr,
    hints: [
      'Сделайте замену t = x². Получится обычное квадратное уравнение относительно t.',
      't² − ${s}t + $pr = 0. Найдите t, потом вернитесь к x: x² = t, у каждого положительного t два корня (±√t).',
    ],
  );
}

Task? _g9e() {
  final c = _pick([-3, -2, 2, 3, 4]), x0 = _ri(-8, 8), b = _ri(-6, 6);
  if (x0 == b) return null;
  final a = c * (x0 - b) - x0;
  final nu = a == 0 ? 'x' : '(${_xs(a)})';
  final de = b == 0 ? 'x' : '(${_xs(-b)})';
  return _roots(
    'Дробное уравнение',
    '$nu/$de = ${_n(c)}',
    [x0],
    (t) => (t + a) / (t - b) - c,
    hints: [
      'Умножьте обе части на знаменатель. Помните: знаменатель не может быть равен нулю.',
      '${_xs(a)} = ${_n(c)}·(${_xs(-b)}). Раскройте скобки и соберите x в одной части.',
    ],
  );
}

// ---------- 10–11 класс ----------

Task? _g11a() {
  final u = _ri(-4, 5), v = _ri(-4, 5), w = _ri(-4, 5);
  if (u == v || v == w || u == w) return null;
  final c2 = -(u + v + w), c1 = u * v + u * w + v * w, c0 = -u * v * w;
  return _roots(
    'Кубическое уравнение',
    '${_expr([(1, 'x³'), (c2, 'x²'), (c1, 'x'), (c0, '')])} = 0',
    [u, v, w],
    (t) => t * t * t + c2 * t * t + c1 * t + c0,
    hints: [
      c0 == 0
          ? 'Свободного члена нет — вынесите x за скобки.'
          : 'Попробуйте подобрать целый корень среди делителей числа ${c0.abs()} (подставляйте ±1, ±2, …).',
      'Число ${_n(u)} — корень (подставьте и убедитесь). Разделите многочлен на (${_xs(-u)}) и решите получившееся квадратное уравнение.',
    ],
  );
}

Task? _g11b() {
  final base = _pick([2, 3, 5]);
  final p = _ri(1, 4), q = _ri(-5, 5), x0 = _ri(-3, 4);
  final n = p * x0 + q;
  final maxN = base == 2 ? 9 : (base == 3 ? 5 : 3);
  if (n < 0 || n > maxN) return null;
  final value = pow(base, n).toInt();
  final e = _expr([(p, 'x'), (q, '')]);
  final ex = e == 'x' ? 'x' : '($e)';
  return _roots(
    'Показательное уравнение',
    '$base^$ex = $value',
    [x0],
    (t) => pow(base, p * t + q).toDouble() - value,
    hints: [
      'Представьте число $value в виде степени с основанием $base.',
      '$value = $base^$n. Значит, показатели степеней равны: $e = $n.',
    ],
  );
}

Task? _g11c() {
  final a = _ri(0, 4), b = _ri(0, 4);
  if (a == b) return null;
  final s = (1 << a) + (1 << b), pr = 1 << (a + b);
  return _roots(
    'Показательное уравнение (замена)',
    '4^x − $s · 2^x + $pr = 0',
    [a, b],
    (t) => pow(4, t).toDouble() - s * pow(2, t).toDouble() + pr,
    hints: [
      'Заметьте: 4^x = (2^x)². Сделайте замену t = 2^x.',
      't² − ${s}t + $pr = 0. Найдите t, затем для каждого t решите уравнение 2^x = t.',
    ],
  );
}

Task? _g11d() {
  final base = _pick([2, 3, 5]);
  final n = _ri(1, base == 2 ? 5 : 3), c = _nz(-9, 9);
  final v = pow(base, n).toInt();
  final x = v - c;
  final sub = {2: '₂', 3: '₃', 5: '₅'}[base]!;
  return _roots(
    'Логарифмическое уравнение',
    'log$sub(${_xs(c)}) = $n',
    [x],
    (t) => log(t + c) / log(base) - n,
    hints: [
      'Вспомните определение: log$sub(A) = $n означает, что A = $base^$n.',
      '${_xs(c)} = $v. Осталось найти x.',
    ],
  );
}

Task? _g11e() {
  final base = _pick([2, 3]);
  final n = _ri(2, base == 2 ? 5 : 3);
  final i = _ri(0, n), x0 = _ri(-3, 6);
  final d1 = pow(base, i).toInt(), d2 = pow(base, n - i).toInt();
  final a1 = d1 - x0, a2 = d2 - x0;
  final x1 = -(a1 + a2) - x0;
  final sub = base == 2 ? '₂' : '₃';
  bool dom(int t) => t + a1 > 0 && t + a2 > 0;
  final cands = <int>{x0, x1}.where(dom).toList();
  return _roots(
    'Логарифмы и ОДЗ',
    'log$sub(${_xs(a1)}) + log$sub(${_xs(a2)}) = $n',
    cands,
    (t) => (log(t + a1) + log(t + a2)) / log(base) - n,
    instruction: 'Найдите все корни (через пробел). Не забудьте про ОДЗ!',
    hints: [
      'Сначала ОДЗ: выражения под логарифмами должны быть больше нуля. Потом сложите логарифмы: log A + log B = log (A · B).',
      '(${_xs(a1)})(${_xs(a2)}) = ${pow(base, n).toInt()}. Решите квадратное уравнение и проверьте корни по ОДЗ.',
    ],
  );
}

Task? _g11f() {
  final b = _ri(1, 4), x0 = b + _ri(2, 7);
  final x1 = 2 * b + 1 - x0;
  final a = b * b - x0 * x1;
  final lhs = a == 0 ? '√x' : '√(${_xs(a)})';
  return _roots(
    'Иррациональное уравнение',
    '$lhs = ${_xs(-b)}',
    [x0],
    (t) => sqrt(t + a) - (t - b),
    instruction: 'Найдите x. Проверьте посторонние корни!',
    hints: [
      'Возведите обе части в квадрат. После этого могут появиться посторонние корни — проверьте подстановкой.',
      '${_xs(a)} = (${_xs(-b)})². Получится: ${_expr([(1, 'x²'), (-(2 * b + 1), 'x'), (b * b - a, '')])} = 0.',
    ],
  );
}

final List<List<Task? Function()>> _gens = [
  [_g56a, _g56b, _g56c, _g56d, _g56e],
  [_g78a, _g78b, _g78c, _g78d, _g78e],
  [_g9a, _g9b, _g9c, _g9d, _g9e],
  [_g11a, _g11b, _g11c, _g11d, _g11e, _g11f],
];

/// Случайная задача для уровня [level] (0..3).
Task generateTask(int level) {
  final gens = _gens[level.clamp(0, _gens.length - 1).toInt()];
  for (var i = 0; i < 80; i++) {
    final t = _pick(gens)();
    if (t != null) return t;
  }
  return _roots('Линейное уравнение', '2x + 6 = 14', [4], (t) => 2 * t + 6 - 14)!;
}

// ---------- Разбор и проверка ответа ----------

double? _parseNum(String t) {
  t = t.replaceAll(',', '.');
  if (t.contains('/')) {
    final p = t.split('/');
    if (p.length != 2) return null;
    final a = double.tryParse(p[0]);
    final b = double.tryParse(p[1]);
    if (a == null || b == null || b == 0) return null;
    return a / b;
  }
  final v = double.tryParse(t);
  if (v == null || v.isNaN || v.isInfinite) return null;
  return v;
}

/// Превращает ввод игрока в список чисел. null — если ввод непонятен.
/// Понимает: "3", "-2 5", "1/2", "1,5", "x=3 y=-2", "±4", "2; 3", "(3, -2)".
List<double>? parseAnswer(String raw) {
  var s = raw.toLowerCase().replaceAll(RegExp(r'[−–—]'), '-');
  s = s.replaceAll(RegExp(r'[xyzху]\d?\s*='), ' ').replaceAll(RegExp(r'[()]'), ' ');
  final out = <double>[];
  for (var tok in s.split(RegExp(r'[;\s]+'))) {
    tok = tok.replaceAll(RegExp(r'[,.]+$'), '');
    if (tok.isEmpty || tok == 'и' || tok == 'или') continue;
    var pm = false;
    if (tok.startsWith('±')) {
      pm = true;
      tok = tok.substring(1);
    } else if (tok.startsWith('+-')) {
      pm = true;
      tok = tok.substring(2);
    }
    final v = _parseNum(tok);
    if (v == null) return null;
    out.add(v);
    if (pm) out.add(-v);
  }
  return out.isEmpty ? null : out;
}

bool isCorrect(Task t, List<double> got) {
  const eps = 1e-6;
  if (t.ordered) {
    if (got.length != t.answer.length) return false;
    for (var i = 0; i < got.length; i++) {
      if ((got[i] - t.answer[i]).abs() > eps) return false;
    }
    return true;
  }
  final g = _uniqSorted(got);
  final a = _uniqSorted(t.answer);
  if (g.length != a.length) return false;
  for (var i = 0; i < g.length; i++) {
    if ((g[i] - a[i]).abs() > eps) return false;
  }
  return true;
}
