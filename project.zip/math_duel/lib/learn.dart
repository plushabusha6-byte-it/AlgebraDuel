import 'package:flutter/material.dart';

import 'common.dart';
import 'equations.dart';

/// Режим обучения: класс → тема → теория, разобранный пример и тренировка.
class LearnScreen extends StatefulWidget {
  const LearnScreen({super.key});

  @override
  State<LearnScreen> createState() => _LearnScreenState();
}

class _LearnScreenState extends State<LearnScreen> {
  int _level = 0;

  @override
  Widget build(BuildContext context) {
    final th = Theme.of(context);
    final topics = topicsFor(_level);
    return Shell(
      title: 'Обучение',
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          const Text('Выберите класс и тему. В каждой теме — объяснение, '
              'разобранный пример и тренировка без ограничения по времени.'),
          const SizedBox(height: 12),
          SegmentedButton<int>(
            showSelectedIcon: false,
            segments: [
              for (var i = 0; i < levelShort.length; i++)
                ButtonSegment<int>(value: i, label: Text(levelShort[i])),
            ],
            selected: {_level},
            onSelectionChanged: (v) => setState(() => _level = v.first),
          ),
          const SizedBox(height: 6),
          Text('${levelNames[_level]}: ${levelTopics[_level]}',
              style: th.textTheme.bodySmall),
          const SizedBox(height: 8),
          for (var i = 0; i < topics.length; i++)
            Card(
              child: ListTile(
                leading: CircleAvatar(
                  radius: 14,
                  child: Text('${i + 1}', style: const TextStyle(fontSize: 12)),
                ),
                title: Text(topics[i].title),
                trailing: const Icon(Icons.chevron_right),
                onTap: () => Navigator.of(context).push(MaterialPageRoute<void>(
                  builder: (_) => TopicScreen(topic: topics[i]),
                )),
              ),
            ),
        ],
      ),
    );
  }
}

class TopicScreen extends StatefulWidget {
  final Topic topic;
  const TopicScreen({super.key, required this.topic});

  @override
  State<TopicScreen> createState() => _TopicScreenState();
}

class _TopicScreenState extends State<TopicScreen> {
  late Task _example = generateFromTopic(widget.topic);
  late Task _task = generateFromTopic(widget.topic);
  final TextEditingController _ctl = TextEditingController();
  int _hints = 0;
  bool _solved = false;
  bool _showSolution = false;
  String? _verdict;
  int _right = 0;
  int _tried = 0;

  @override
  void dispose() {
    _ctl.dispose();
    super.dispose();
  }

  void _next() {
    setState(() {
      _task = generateFromTopic(widget.topic);
      _hints = 0;
      _solved = false;
      _showSolution = false;
      _verdict = null;
      _ctl.clear();
    });
  }

  void _check() {
    FocusManager.instance.primaryFocus?.unfocus();
    final text = _ctl.text.trim();
    if (text.isEmpty) return;
    final parsed = parseAnswer(text);
    if (parsed == null) {
      snack(context, 'Не понял ответ. Примеры: 3   или   -2 5   или   1/2');
      return;
    }
    final ok = isCorrect(_task, parsed);
    setState(() {
      _tried++;
      if (ok) {
        _right++;
        _solved = true;
        _verdict = 'Верно! 🎉';
      } else {
        _verdict = 'Пока неверно. Попробуйте ещё раз, возьмите подсказку '
            'или посмотрите решение.';
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final th = Theme.of(context);
    final t = widget.topic;
    final hints = _task.hints;
    final shown = _hints < hints.length ? _hints : hints.length;
    return Shell(
      title: t.title,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Text('Теория', style: th.textTheme.titleMedium),
          const SizedBox(height: 6),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Text(t.theory, style: th.textTheme.bodyLarge?.copyWith(height: 1.45)),
            ),
          ),
          const SizedBox(height: 12),
          Text('Разобранный пример', style: th.textTheme.titleMedium),
          const SizedBox(height: 6),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Text(_example.text,
                      textAlign: TextAlign.center,
                      style: const TextStyle(
                          fontSize: 22, fontWeight: FontWeight.w600, height: 1.4)),
                  const SizedBox(height: 4),
                  Text(_example.instruction,
                      textAlign: TextAlign.center, style: th.textTheme.bodySmall),
                  const Divider(height: 24),
                  StepsList(steps: _example.steps),
                  const SizedBox(height: 8),
                  Text('Ответ: ${_example.answerText}',
                      style: th.textTheme.titleMedium
                          ?.copyWith(fontWeight: FontWeight.bold)),
                  Align(
                    alignment: Alignment.centerRight,
                    child: TextButton.icon(
                      onPressed: () =>
                          setState(() => _example = generateFromTopic(t)),
                      icon: const Icon(Icons.refresh),
                      label: const Text('Другой пример'),
                    ),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              Text('Попробуйте сами', style: th.textTheme.titleMedium),
              const Spacer(),
              Text('Верно: $_right из $_tried', style: th.textTheme.labelLarge),
            ],
          ),
          const SizedBox(height: 6),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Text(_task.text,
                      textAlign: TextAlign.center,
                      style: const TextStyle(
                          fontSize: 24, fontWeight: FontWeight.w600, height: 1.4)),
                  const SizedBox(height: 4),
                  Text(_task.instruction,
                      textAlign: TextAlign.center, style: th.textTheme.bodySmall),
                  for (var i = 0; i < shown; i++)
                    Card(
                      color: th.colorScheme.tertiaryContainer,
                      margin: const EdgeInsets.only(top: 8),
                      child: Padding(
                        padding: const EdgeInsets.all(12),
                        child: Text('💡 Подсказка ${i + 1}: ${hints[i]}'),
                      ),
                    ),
                  const SizedBox(height: 12),
                  if (!_solved)
                    TextField(
                      controller: _ctl,
                      autocorrect: false,
                      enableSuggestions: false,
                      decoration: const InputDecoration(
                        labelText: 'Ваш ответ',
                        helperText: 'Несколько ответов — через пробел',
                        border: OutlineInputBorder(),
                      ),
                      onSubmitted: (_) => _check(),
                    ),
                  if (_verdict != null)
                    Padding(
                      padding: const EdgeInsets.only(top: 8),
                      child: Text(
                        _verdict!,
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          fontWeight: FontWeight.w600,
                          color: _solved ? th.colorScheme.primary : th.colorScheme.error,
                        ),
                      ),
                    ),
                  const SizedBox(height: 8),
                  Wrap(
                    alignment: WrapAlignment.center,
                    spacing: 8,
                    runSpacing: 4,
                    children: [
                      if (!_solved)
                        FilledButton(onPressed: _check, child: const Text('Проверить')),
                      if (!_solved && shown < hints.length)
                        OutlinedButton.icon(
                          onPressed: () => setState(() => _hints++),
                          icon: const Icon(Icons.lightbulb_outline),
                          label: const Text('Подсказка'),
                        ),
                      OutlinedButton(
                        onPressed: () => setState(() => _showSolution = !_showSolution),
                        child: Text(_showSolution ? 'Скрыть решение' : 'Показать решение'),
                      ),
                      if (_solved || _showSolution)
                        FilledButton.tonal(
                          onPressed: _next,
                          child: const Text('Следующая задача'),
                        ),
                    ],
                  ),
                  if (_showSolution) ...[
                    const Divider(height: 24),
                    StepsList(steps: _task.steps),
                    const SizedBox(height: 8),
                    Text('Ответ: ${_task.answerText}',
                        style: th.textTheme.titleMedium
                            ?.copyWith(fontWeight: FontWeight.bold)),
                  ],
                ],
              ),
            ),
          ),
          const SizedBox(height: 16),
        ],
      ),
    );
  }
}
