import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'screens.dart';
import 'session.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setPreferredOrientations([
    DeviceOrientation.portraitUp,
    DeviceOrientation.portraitDown,
  ]);
  runApp(const MathDuelApp());
}

class MathDuelApp extends StatefulWidget {
  const MathDuelApp({super.key});

  @override
  State<MathDuelApp> createState() => _MathDuelAppState();
}

class _MathDuelAppState extends State<MathDuelApp> {
  final GameSession session = GameSession();

  @override
  void dispose() {
    session.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Матем-дуэль',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(colorSchemeSeed: Colors.indigo, useMaterial3: true),
      darkTheme: ThemeData(
        colorSchemeSeed: Colors.indigo,
        brightness: Brightness.dark,
        useMaterial3: true,
      ),
      themeMode: ThemeMode.system,
      home: Root(s: session),
    );
  }
}
