import 'package:flutter/material.dart';

import 'common.dart';
import 'scratch.dart';
import 'session.dart';

/// Подробный разбор одного примера: условие, правильное решение,
/// мой ответ, ответ соперника и мой черновик.
class RoundDetail extends StatelessWidget {
  final RoundRecord r;
  final String oppName;
  const RoundDetail({super.key, required this.r, required this.oppName});

  Widget _answer(BuildContext c, String who, String ans, bool ok, int pts) {
    final th = Theme.of(c);
    return Card(
      color: ok ? th.colorScheme.primaryContainer : th.colorScheme.errorContainer,
      child: ListTile(
        leading: Icon(ok ? Icons.check_circle : Icons.cancel, size: 30),
        title: Text(who),
        subtitle: Text('Ответ: $ans'),
        trailing: Text('+$pts',
            style: th.textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold)),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final th = Theme.of(context);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Text(r.topic, textAlign: TextAlign.center, style: th.textTheme.labelMedium),
        const SizedBox(height: 6),
        Card(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              children: [
                Text(r.text,
                    textAlign: TextAlign.center,
                    style: const TextStyle(
                        fontSize: 24, fontWeight: FontWeight.w600, height: 1.4)),
                const Divider(height: 24),
                const Text('Правильный ответ'),
                const SizedBox(height: 4),
                Text(r.correct,
                    textAlign: TextAlign.center,
                    style: th.textTheme.headlineSmall
                        ?.copyWith(fontWeight: FontWeight.bold)),
              ],
            ),
          ),
        ),
        const SizedBox(height: 4),
        _answer(context, 'Вы', r.myAnswer, r.myOk, r.myPts),
        _answer(context, oppName, r.oppAnswer, r.oppOk, r.oppPts),
        const SizedBox(height: 12),
        Text('Правильное решение', style: th.textTheme.titleMedium),
        const SizedBox(height: 6),
        StepsList(steps: r.steps),
        const SizedBox(height: 16),
        Text('Ваш черновик', style: th.textTheme.titleMedium),
        const SizedBox(height: 6),
        ScratchView(controller: r.pad),
      ],
    );
  }
}

/// Один пример на отдельном экране.
class RoundDetailScreen extends StatelessWidget {
  final RoundRecord r;
  final String oppName;
  const RoundDetailScreen({super.key, required this.r, required this.oppName});

  @override
  Widget build(BuildContext context) {
    return Shell(
      title: 'Пример ${r.no}: разбор',
      child: RoundDetail(r: r, oppName: oppName),
    );
  }
}

/// Список всех примеров игры — для просмотра после финала.
class ReviewListScreen extends StatelessWidget {
  final GameSession s;
  const ReviewListScreen({super.key, required this.s});

  @override
  Widget build(BuildContext context) {
    final th = Theme.of(context);
    return Shell(
      title: 'Разбор примеров',
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          if (s.history.isEmpty) const Text('Сыгранных примеров пока нет.'),
          for (final r in s.history)
            Card(
              child: ListTile(
                leading: Icon(
                  r.myOk ? Icons.check_circle : Icons.cancel,
                  color: r.myOk ? th.colorScheme.primary : th.colorScheme.error,
                ),
                title: Text('Пример ${r.no}: ${r.text}'),
                subtitle: Text('Ваш ответ: ${r.myAnswer}  •  верно: ${r.correct}'),
                trailing: const Icon(Icons.chevron_right),
                onTap: () => Navigator.of(context).push(MaterialPageRoute<void>(
                  builder: (_) => RoundDetailScreen(r: r, oppName: s.oppName),
                )),
              ),
            ),
        ],
      ),
    );
  }
}
