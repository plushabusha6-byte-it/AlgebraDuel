import 'package:flutter/material.dart';

/// Одна линия, нарисованная пальцем.
class Stroke {
  final List<Offset> pts;
  final Color color;
  final double width;
  final bool erase;

  Stroke(this.pts, this.color, this.width, this.erase);
}

/// Состояние черновика: несколько листов, ручка, ластик.
class ScratchController extends ChangeNotifier {
  static const List<Color> palette = [
    Color(0xFF212121),
    Color(0xFF1565C0),
    Color(0xFFC62828),
  ];
  static const int maxPages = 5;

  final List<List<Stroke>> pages = [[]];
  int page = 0;
  Color color = palette.first;
  bool eraser = false;

  int? _ptr;
  Stroke? _cur;

  List<Stroke> get strokes => pages[page];

  void start(int pointer, Offset p) {
    if (_ptr != null) return; // только один палец
    _ptr = pointer;
    final st = Stroke([p], color, eraser ? 26.0 : 3.2, eraser);
    _cur = st;
    strokes.add(st);
    notifyListeners();
  }

  void extend(int pointer, Offset p) {
    if (pointer != _ptr || _cur == null) return;
    _cur!.pts.add(p);
    notifyListeners();
  }

  void end(int pointer) {
    if (pointer != _ptr) return;
    _ptr = null;
    _cur = null;
  }

  void cancelStroke() {
    _ptr = null;
    _cur = null;
  }

  void setColor(Color c) {
    color = c;
    eraser = false;
    notifyListeners();
  }

  void toggleEraser() {
    eraser = !eraser;
    notifyListeners();
  }

  void undo() {
    if (strokes.isEmpty) return;
    strokes.removeLast();
    _ptr = null;
    _cur = null;
    notifyListeners();
  }

  void clearPage() {
    strokes.clear();
    _ptr = null;
    _cur = null;
    notifyListeners();
  }

  void setPage(int i) {
    if (i < 0 || i >= pages.length) return;
    page = i;
    _ptr = null;
    _cur = null;
    notifyListeners();
  }

  void addPage() {
    if (pages.length >= maxPages) return;
    pages.add([]);
    page = pages.length - 1;
    _ptr = null;
    _cur = null;
    notifyListeners();
  }
}

class _PadPainter extends CustomPainter {
  final ScratchController c;

  _PadPainter(this.c) : super(repaint: c);

  @override
  void paint(Canvas canvas, Size size) {
    final rect = Offset.zero & size;
    canvas.drawRect(rect, Paint()..color = Colors.white);

    // Тетрадная клетка.
    final grid = Paint()
      ..color = const Color(0xFFD3E4F4)
      ..strokeWidth = 1;
    for (double x = 0; x <= size.width; x += 24) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), grid);
    }
    for (double y = 0; y <= size.height; y += 24) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), grid);
    }

    // Рисунок — на отдельном слое, чтобы ластик стирал только его, а не клетку.
    canvas.saveLayer(rect, Paint());
    for (final s in c.strokes) {
      final paint = Paint()
        ..color = s.color
        ..strokeWidth = s.width
        ..strokeCap = StrokeCap.round
        ..strokeJoin = StrokeJoin.round
        ..style = PaintingStyle.stroke
        ..isAntiAlias = true;
      if (s.erase) paint.blendMode = BlendMode.clear;

      if (s.pts.length == 1) {
        paint.style = PaintingStyle.fill;
        canvas.drawCircle(s.pts.first, s.width / 2, paint);
        continue;
      }
      final path = Path()..moveTo(s.pts.first.dx, s.pts.first.dy);
      for (var i = 1; i < s.pts.length; i++) {
        final prev = s.pts[i - 1];
        final cur = s.pts[i];
        final mid = Offset((prev.dx + cur.dx) / 2, (prev.dy + cur.dy) / 2);
        path.quadraticBezierTo(prev.dx, prev.dy, mid.dx, mid.dy);
      }
      path.lineTo(s.pts.last.dx, s.pts.last.dy);
      canvas.drawPath(path, paint);
    }
    canvas.restore();
  }

  @override
  bool shouldRepaint(covariant _PadPainter oldDelegate) => true;
}

/// Лист, на котором рисуют пальцем.
class ScratchPad extends StatelessWidget {
  final ScratchController controller;

  const ScratchPad({super.key, required this.controller});

  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(12),
      child: Listener(
        behavior: HitTestBehavior.opaque,
        onPointerDown: (e) => controller.start(e.pointer, e.localPosition),
        onPointerMove: (e) => controller.extend(e.pointer, e.localPosition),
        onPointerUp: (e) => controller.end(e.pointer),
        onPointerCancel: (e) => controller.end(e.pointer),
        child: CustomPaint(
          painter: _PadPainter(controller),
          child: const SizedBox.expand(),
        ),
      ),
    );
  }
}

/// Панель инструментов: цвета, ластик, отмена, очистка, листы.
class ScratchTools extends StatelessWidget {
  final ScratchController controller;

  const ScratchTools({super.key, required this.controller});

  @override
  Widget build(BuildContext context) {
    final th = Theme.of(context);
    return ListenableBuilder(
      listenable: controller,
      builder: (context, _) {
        final c = controller;
        return Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Wrap(
              alignment: WrapAlignment.center,
              crossAxisAlignment: WrapCrossAlignment.center,
              spacing: 2,
              children: [
                for (final col in ScratchController.palette)
                  GestureDetector(
                    behavior: HitTestBehavior.opaque,
                    onTap: () => c.setColor(col),
                    child: Padding(
                      padding: const EdgeInsets.all(8),
                      child: Container(
                        width: 28,
                        height: 28,
                        decoration: BoxDecoration(
                          color: col,
                          shape: BoxShape.circle,
                          border: Border.all(
                            color: (!c.eraser && c.color == col)
                                ? th.colorScheme.primary
                                : Colors.transparent,
                            width: 3,
                          ),
                        ),
                      ),
                    ),
                  ),
                if (c.eraser)
                  IconButton.filledTonal(
                    tooltip: 'Ластик',
                    icon: const Icon(Icons.cleaning_services),
                    onPressed: c.toggleEraser,
                  )
                else
                  IconButton(
                    tooltip: 'Ластик',
                    icon: const Icon(Icons.cleaning_services),
                    onPressed: c.toggleEraser,
                  ),
                IconButton(
                  tooltip: 'Отменить',
                  icon: const Icon(Icons.undo),
                  onPressed: c.strokes.isEmpty ? null : c.undo,
                ),
                IconButton(
                  tooltip: 'Очистить лист',
                  icon: const Icon(Icons.delete_outline),
                  onPressed: c.strokes.isEmpty ? null : c.clearPage,
                ),
              ],
            ),
            Wrap(
              alignment: WrapAlignment.center,
              spacing: 6,
              children: [
                for (var i = 0; i < c.pages.length; i++)
                  ChoiceChip(
                    label: Text('Лист ${i + 1}'),
                    selected: c.page == i,
                    onSelected: (_) => c.setPage(i),
                  ),
                if (c.pages.length < ScratchController.maxPages)
                  ActionChip(
                    label: const Icon(Icons.add, size: 18),
                    onPressed: c.addPage,
                  ),
              ],
            ),
          ],
        );
      },
    );
  }
}
