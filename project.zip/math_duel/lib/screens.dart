import 'package:flutter/material.dart';

import 'equations.dart';
import 'scratch.dart';
import 'session.dart';

String mmss(int sec) {
  final m = sec ~/ 60;
  final s = sec % 60;
  return '$m:${s.toString().padLeft(2, '0')}';
}

/// Выбирает экран по текущей фазе игры.
class Root extends StatelessWidget {
  final GameSession s;
  const Root({super.key, required this.s});

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: s,
      builder: (context, _) {
        switch (s.phase) {
          case Phase.menu:
            return MenuScreen(s: s);
          case Phase.waiting:
          case Phase.connecting:
          case Phase.ready:
            return LobbyScreen(s: s);
          case Phase.playing:
            return RoundScreen(s: s);
          case Phase.roundResult:
            return ResultScreen(s: s);
          case Phase.finished:
            return FinalScreen(s: s);
          case Phase.closed:
            return ClosedScreen(s: s);
        }
      },
    );
  }
}

class Shell extends StatelessWidget {
  final Widget child;
  final String? title;
  const Shell({super.key, required this.child, this.title});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: title == null ? null : AppBar(title: Text(title!), centerTitle: true),
      body: SafeArea(
        child: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 560),
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(16),
              child: child,
            ),
          ),
        ),
      ),
    );
  }
}

void _snack(BuildContext context, String text) {
  ScaffoldMessenger.of(context)
    ..hideCurrentSnackBar()
    ..showSnackBar(SnackBar(content: Text(text)));
}

// ======================= Меню =======================

class MenuScreen extends StatefulWidget {
  final GameSession s;
  const MenuScreen({super.key, required this.s});

  @override
  State<MenuScreen> createState() => _MenuScreenState();
}

class _MenuScreenState extends State<MenuScreen> {
  late final TextEditingController _name = TextEditingController(
    text: widget.s.myName == 'Игрок' ? '' : widget.s.myName,
  );
  late final TextEditingController _ip = TextEditingController(text: widget.s.lastIp);

  @override
  void dispose() {
    _name.dispose();
    _ip.dispose();
    super.dispose();
  }

  void _join() {
    final ip = _ip.text.trim().replaceAll(',', '.');
    if (!RegExp(r'^\d{1,3}(\.\d{1,3}){3}$').hasMatch(ip)) {
      _snack(context, 'Введите адрес из четырёх чисел, например 192.168.1.5');
      return;
    }
    widget.s.joinGame(_name.text, ip);
  }

  @override
  Widget build(BuildContext context) {
    final th = Theme.of(context);
    return Shell(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          const SizedBox(height: 8),
          Icon(Icons.calculate_rounded, size: 64, color: th.colorScheme.primary),
          const SizedBox(height: 8),
          Text('Матем-дуэль',
              textAlign: TextAlign.center, style: th.textTheme.headlineLarge),
          const SizedBox(height: 4),
          Text(
            'Решай уравнения быстрее соперника.\nИграют двое — по одной Wi-Fi сети.',
            textAlign: TextAlign.center,
            style: th.textTheme.bodyMedium,
          ),
          const SizedBox(height: 20),
          TextField(
            controller: _name,
            maxLength: 16,
            textCapitalization: TextCapitalization.words,
            decoration: const InputDecoration(
              labelText: 'Ваше имя',
              border: OutlineInputBorder(),
              counterText: '',
            ),
          ),
          const SizedBox(height: 16),
          FilledButton.icon(
            onPressed: () => widget.s.hostGame(_name.text),
            icon: const Icon(Icons.add_circle_outline),
            label: const Padding(
              padding: EdgeInsets.symmetric(vertical: 12),
              child: Text('Создать игру', style: TextStyle(fontSize: 18)),
            ),
          ),
          const SizedBox(height: 16),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Text('Подключиться к другу', style: th.textTheme.titleMedium),
                  const SizedBox(height: 4),
                  const Text(
                      'Друг создаёт игру и видит у себя адрес. Введите его здесь.'),
                  const SizedBox(height: 12),
                  TextField(
                    controller: _ip,
                    keyboardType:
                        const TextInputType.numberWithOptions(decimal: true),
                    decoration: const InputDecoration(
                      labelText: 'Адрес, например 192.168.1.5',
                      border: OutlineInputBorder(),
                    ),
                    onSubmitted: (_) => _join(),
                  ),
                  const SizedBox(height: 12),
                  OutlinedButton.icon(
                    onPressed: _join,
                    icon: const Icon(Icons.wifi),
                    label: const Padding(
                      padding: EdgeInsets.symmetric(vertical: 10),
                      child: Text('Подключиться'),
                    ),
                  ),
                ],
              ),
            ),
          ),
          if (widget.s.error != null) ...[
            const SizedBox(height: 12),
            Text(widget.s.error!,
                style: TextStyle(color: th.colorScheme.error),
                textAlign: TextAlign.center),
          ],
          const SizedBox(height: 8),
          const ExpansionTile(
            title: Text('Правила'),
            childrenPadding: EdgeInsets.fromLTRB(16, 0, 16, 12),
            expandedCrossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                '• Оба игрока получают одно и то же уравнение и одинаковое время.\n'
                '• Верный ответ — 1 очко. Кто первым ответил верно — ещё +1.\n'
                '• Ответ можно отправить только один раз.\n'
                '• Решать удобно на вкладке «Черновик» — пишите пальцем на клетчатом листе.\n'
                '• На каждый пример у вас 2 подсказки.\n'
                '• Несколько корней записывайте через пробел. Дроби: 3/2 или 1,5.\n'
                '• В конце побеждает тот, у кого больше очков.',
              ),
            ],
          ),
        ],
      ),
    );
  }
}

// ======================= Лобби =======================

class LobbyScreen extends StatelessWidget {
  final GameSession s;
  const LobbyScreen({super.key, required this.s});

  Widget _label(BuildContext c, String t) => Padding(
        padding: const EdgeInsets.only(top: 16, bottom: 8),
        child: Text(t, style: Theme.of(c).textTheme.titleSmall),
      );

  @override
  Widget build(BuildContext context) {
    final th = Theme.of(context);
    final connected = s.phase == Phase.ready;

    if (!s.isHost) {
      return Shell(
        title: 'Подключение',
        child: Column(
          children: [
            const SizedBox(height: 40),
            if (!connected) const CircularProgressIndicator(),
            if (connected)
              Icon(Icons.check_circle, size: 64, color: th.colorScheme.primary),
            const SizedBox(height: 20),
            Text(
              connected
                  ? 'Подключено к игроку ${s.oppName}.\nЖдём, когда он начнёт игру…'
                  : 'Подключаемся…',
              textAlign: TextAlign.center,
              style: th.textTheme.titleMedium,
            ),
            const SizedBox(height: 32),
            TextButton(onPressed: s.leave, child: const Text('Выйти')),
          ],
        ),
      );
    }

    final ip = s.myIps.isEmpty ? 'не найден — включите Wi-Fi' : s.myIps.first;
    return Shell(
      title: 'Ваша игра',
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                children: [
                  const Text('Ваш адрес в Wi-Fi'),
                  const SizedBox(height: 4),
                  SelectableText(
                    ip,
                    style: th.textTheme.headlineMedium
                        ?.copyWith(fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 8),
                  const Text(
                    'Друг вводит его в поле «Подключиться». Оба телефона должны быть в одной Wi-Fi сети.',
                    textAlign: TextAlign.center,
                  ),
                  if (s.myIps.length > 1) ...[
                    const SizedBox(height: 8),
                    Text(
                      'Если не подключается, попробуйте: ${s.myIps.skip(1).join(', ')}',
                      textAlign: TextAlign.center,
                      style: th.textTheme.bodySmall,
                    ),
                  ],
                ],
              ),
            ),
          ),
          const SizedBox(height: 12),
          ListTile(
            leading: connected
                ? Icon(Icons.check_circle, color: th.colorScheme.primary)
                : const SizedBox(
                    width: 24,
                    height: 24,
                    child: CircularProgressIndicator(strokeWidth: 2),
                  ),
            title: Text(connected ? 'Соперник: ${s.oppName}' : 'Ждём соперника…'),
          ),
          _label(context, 'Класс'),
          SegmentedButton<int>(
            showSelectedIcon: false,
            segments: [
              for (var i = 0; i < levelShort.length; i++)
                ButtonSegment<int>(value: i, label: Text(levelShort[i])),
            ],
            selected: {s.level},
            onSelectionChanged: (v) => s.setLevel(v.first),
          ),
          const SizedBox(height: 6),
          Text('${levelNames[s.level]}: ${levelTopics[s.level]}',
              style: th.textTheme.bodySmall),
          _label(context, 'Количество примеров'),
          Wrap(
            spacing: 8,
            children: [
              for (final r in const [3, 5, 7, 10])
                ChoiceChip(
                  label: Text('$r'),
                  selected: s.rounds == r,
                  onSelected: (_) => s.setRounds(r),
                ),
            ],
          ),
          _label(context, 'Минут на один пример'),
          Wrap(
            spacing: 8,
            children: [
              for (final m in const [1, 2, 3, 4, 5, 6, 8])
                ChoiceChip(
                  label: Text('$m'),
                  selected: s.minutes == m,
                  onSelected: (_) => s.setMinutes(m),
                ),
            ],
          ),
          const SizedBox(height: 24),
          FilledButton(
            onPressed: connected ? s.startGame : null,
            child: const Padding(
              padding: EdgeInsets.symmetric(vertical: 12),
              child: Text('Начать игру', style: TextStyle(fontSize: 18)),
            ),
          ),
          const SizedBox(height: 8),
          TextButton(onPressed: s.leave, child: const Text('Выйти')),
        ],
      ),
    );
  }
}

// ======================= Раунд =======================

class RoundScreen extends StatefulWidget {
  final GameSession s;
  const RoundScreen({super.key, required this.s});

  @override
  State<RoundScreen> createState() => _RoundScreenState();
}

class _RoundScreenState extends State<RoundScreen> {
  final TextEditingController _ctl = TextEditingController();
  final ScratchController _pad = ScratchController();
  int _tab = 0; // 0 — задача, 1 — черновик

  @override
  void dispose() {
    _ctl.dispose();
    _pad.dispose();
    super.dispose();
  }

  void _setTab(int t) {
    FocusManager.instance.primaryFocus?.unfocus();
    _pad.cancelStroke();
    setState(() => _tab = t);
  }

  Future<void> _submit() async {
    final text = _ctl.text.trim();
    if (text.isEmpty) return;
    if (parseAnswer(text) == null) {
      _snack(context, 'Не понял ответ. Примеры: 3   или   -2 5   или   1/2');
      return;
    }
    final ok = await showDialog<bool>(
      context: context,
      builder: (c) => AlertDialog(
        title: const Text('Отправить ответ?'),
        content: Text('«$text»\n\nИзменить ответ потом будет нельзя.'),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(c, false), child: const Text('Назад')),
          FilledButton(
              onPressed: () => Navigator.pop(c, true), child: const Text('Отправить')),
        ],
      ),
    );
    if (ok != true || !mounted) return;
    final err = widget.s.submit(text);
    if (err != null && mounted) _snack(context, err);
  }

  Widget _tabs() {
    return SegmentedButton<int>(
      showSelectedIcon: false,
      segments: const <ButtonSegment<int>>[
        ButtonSegment<int>(
            value: 0, icon: Icon(Icons.edit_note), label: Text('Задача')),
        ButtonSegment<int>(value: 1, icon: Icon(Icons.draw), label: Text('Черновик')),
      ],
      selected: {_tab},
      onSelectionChanged: (v) => _setTab(v.first),
    );
  }

  @override
  Widget build(BuildContext context) {
    return _tab == 0 ? _taskView(context) : _padView(context);
  }

  // ----- Вкладка «Задача» -----

  Widget _taskView(BuildContext context) {
    final s = widget.s;
    final th = Theme.of(context);
    final low = s.remaining <= 30;
    final frac = s.totalSeconds == 0 ? 0.0 : s.remaining / s.totalSeconds;

    return Shell(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          _ScoreBar(s: s),
          const SizedBox(height: 12),
          _tabs(),
          const SizedBox(height: 12),
          Text('Пример ${s.roundNo} из ${s.totalRounds}',
              textAlign: TextAlign.center, style: th.textTheme.labelLarge),
          const SizedBox(height: 4),
          Text(
            mmss(s.remaining),
            textAlign: TextAlign.center,
            style: th.textTheme.displaySmall?.copyWith(
              fontWeight: FontWeight.bold,
              color: low ? th.colorScheme.error : null,
            ),
          ),
          const SizedBox(height: 6),
          LinearProgressIndicator(value: frac.clamp(0.0, 1.0).toDouble(), minHeight: 6),
          const SizedBox(height: 16),
          Text(s.curTopic,
              textAlign: TextAlign.center, style: th.textTheme.labelMedium),
          const SizedBox(height: 6),
          Card(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 28),
              child: Center(
                child: Text(
                  s.curText,
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                      fontSize: 28, fontWeight: FontWeight.w600, height: 1.5),
                ),
              ),
            ),
          ),
          const SizedBox(height: 8),
          Text(s.curInstruction,
              textAlign: TextAlign.center, style: th.textTheme.bodyMedium),
          HintsBox(s: s),
          const SizedBox(height: 16),
          if (!s.iAnswered) ...[
            if (s.oppAnswered)
              Padding(
                padding: const EdgeInsets.only(bottom: 8),
                child: Text('⚡ ${s.oppName} уже ответил!',
                    textAlign: TextAlign.center,
                    style: TextStyle(color: th.colorScheme.tertiary)),
              ),
            TextField(
              controller: _ctl,
              autocorrect: false,
              enableSuggestions: false,
              decoration: const InputDecoration(
                labelText: 'Ваш ответ',
                helperText: 'Несколько ответов — через пробел',
                border: OutlineInputBorder(),
              ),
              onSubmitted: (_) => _submit(),
            ),
            const SizedBox(height: 12),
            FilledButton(
              onPressed: _submit,
              child: const Padding(
                padding: EdgeInsets.symmetric(vertical: 12),
                child: Text('Отправить ответ', style: TextStyle(fontSize: 18)),
              ),
            ),
          ] else
            Card(
              color: th.colorScheme.secondaryContainer,
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  children: [
                    Text('Ваш ответ отправлен: ${s.myAnswerShown ?? ''}',
                        textAlign: TextAlign.center,
                        style: th.textTheme.titleMedium),
                    const SizedBox(height: 8),
                    Text(
                      s.oppAnswered
                          ? 'Считаем результат…'
                          : 'Ждём, пока ${s.oppName} ответит или выйдет время…',
                      textAlign: TextAlign.center,
                    ),
                  ],
                ),
              ),
            ),
        ],
      ),
    );
  }

  // ----- Вкладка «Черновик» -----

  Widget _padView(BuildContext context) {
    final s = widget.s;
    final th = Theme.of(context);
    final low = s.remaining <= 30;

    return Scaffold(
      body: SafeArea(
        child: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 700),
            child: Padding(
              padding: const EdgeInsets.fromLTRB(12, 8, 12, 8),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  _tabs(),
                  const SizedBox(height: 6),
                  Row(
                    children: [
                      Text('Пример ${s.roundNo}/${s.totalRounds}',
                          style: th.textTheme.labelLarge),
                      const Spacer(),
                      Text(
                        mmss(s.remaining),
                        style: th.textTheme.titleLarge?.copyWith(
                          fontWeight: FontWeight.bold,
                          color: low ? th.colorScheme.error : null,
                        ),
                      ),
                    ],
                  ),
                  Text(
                    s.curText,
                    textAlign: TextAlign.center,
                    style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w600),
                  ),
                  ConstrainedBox(
                    constraints: const BoxConstraints(maxHeight: 130),
                    child: SingleChildScrollView(child: HintsBox(s: s, compact: true)),
                  ),
                  const SizedBox(height: 6),
                  Expanded(child: ScratchPad(controller: _pad)),
                  const SizedBox(height: 4),
                  ScratchTools(controller: _pad),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

/// Открытые подсказки и кнопка «Подсказка (осталось N)».
class HintsBox extends StatelessWidget {
  final GameSession s;
  final bool compact;
  const HintsBox({super.key, required this.s, this.compact = false});

  @override
  Widget build(BuildContext context) {
    final th = Theme.of(context);
    final shown = s.hintsShown;
    final canUse = s.hintsLeft > 0 && !s.iAnswered;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        for (var i = 0; i < shown.length; i++)
          Card(
            color: th.colorScheme.tertiaryContainer,
            margin: const EdgeInsets.only(top: 8),
            child: Padding(
              padding: EdgeInsets.all(compact ? 8 : 12),
              child: Text(
                '💡 Подсказка ${i + 1}: ${shown[i]}',
                style: compact ? th.textTheme.bodySmall : th.textTheme.bodyMedium,
              ),
            ),
          ),
        const SizedBox(height: 4),
        Align(
          alignment: Alignment.center,
          child: OutlinedButton.icon(
            onPressed: canUse ? s.useHint : null,
            icon: const Icon(Icons.lightbulb_outline),
            label: Text('Подсказка (осталось ${s.hintsLeft})'),
          ),
        ),
      ],
    );
  }
}

class _ScoreBar extends StatelessWidget {
  final GameSession s;
  const _ScoreBar({required this.s});

  @override
  Widget build(BuildContext context) {
    final th = Theme.of(context);
    Widget side(String name, int score, CrossAxisAlignment al) => Expanded(
          child: Column(
            crossAxisAlignment: al,
            children: [
              Text(name, overflow: TextOverflow.ellipsis, style: th.textTheme.labelLarge),
              Text('$score',
                  style: th.textTheme.headlineMedium
                      ?.copyWith(fontWeight: FontWeight.bold)),
            ],
          ),
        );
    return Row(
      children: [
        side('Вы', s.myScore, CrossAxisAlignment.start),
        Text(':', style: th.textTheme.headlineMedium),
        side(s.oppName, s.oppScore, CrossAxisAlignment.end),
      ],
    );
  }
}

// ======================= Итог раунда =======================

class ResultScreen extends StatelessWidget {
  final GameSession s;
  const ResultScreen({super.key, required this.s});

  Widget _player(BuildContext c, String name, String ans, bool ok, int pts) {
    final th = Theme.of(c);
    return Card(
      color: ok ? th.colorScheme.primaryContainer : th.colorScheme.errorContainer,
      child: ListTile(
        leading: Icon(ok ? Icons.check_circle : Icons.cancel, size: 32),
        title: Text(name),
        subtitle: Text('Ответ: $ans'),
        trailing: Text('+$pts',
            style: th.textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.bold)),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final th = Theme.of(context);
    final o = s.outcome;
    return Shell(
      title: 'Пример ${s.roundNo} из ${s.totalRounds}',
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          _ScoreBar(s: s),
          const SizedBox(height: 16),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                children: [
                  Text(s.curText,
                      textAlign: TextAlign.center,
                      style: const TextStyle(fontSize: 20, height: 1.4)),
                  const Divider(height: 24),
                  const Text('Правильный ответ'),
                  const SizedBox(height: 4),
                  Text(o?.correct ?? '',
                      textAlign: TextAlign.center,
                      style: th.textTheme.headlineSmall
                          ?.copyWith(fontWeight: FontWeight.bold)),
                ],
              ),
            ),
          ),
          const SizedBox(height: 8),
          if (o != null) ...[
            _player(context, 'Вы', o.myAnswer, o.myOk, o.myPts),
            _player(context, s.oppName, o.oppAnswer, o.oppOk, o.oppPts),
          ],
          const SizedBox(height: 16),
          if (s.isHost)
            FilledButton(
              onPressed: s.proceed,
              child: Padding(
                padding: const EdgeInsets.symmetric(vertical: 12),
                child: Text(s.lastRound ? 'Показать итоги' : 'Следующий пример',
                    style: const TextStyle(fontSize: 18)),
              ),
            )
          else
            Text(
              s.lastRound
                  ? 'Ждём итоги от ${s.oppName}…'
                  : 'Ждём, пока ${s.oppName} запустит следующий пример…',
              textAlign: TextAlign.center,
            ),
        ],
      ),
    );
  }
}

// ======================= Финал =======================

class FinalScreen extends StatelessWidget {
  final GameSession s;
  const FinalScreen({super.key, required this.s});

  @override
  Widget build(BuildContext context) {
    final th = Theme.of(context);
    final String title;
    if (s.myScore > s.oppScore) {
      title = '🏆 Вы победили!';
    } else if (s.myScore < s.oppScore) {
      title = 'Победил ${s.oppName}';
    } else {
      title = '🤝 Ничья!';
    }
    return Shell(
      title: 'Игра окончена',
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          const SizedBox(height: 24),
          Text(title,
              textAlign: TextAlign.center, style: th.textTheme.headlineMedium),
          const SizedBox(height: 24),
          _ScoreBar(s: s),
          const SizedBox(height: 32),
          if (s.isHost && !s.oppLeft)
            FilledButton(
              onPressed: s.backToLobby,
              child: const Padding(
                padding: EdgeInsets.symmetric(vertical: 12),
                child: Text('Сыграть ещё', style: TextStyle(fontSize: 18)),
              ),
            ),
          if (!s.isHost && !s.oppLeft)
            Text('Ждём, вдруг ${s.oppName} захочет сыграть ещё…',
                textAlign: TextAlign.center),
          if (s.oppLeft)
            Text('${s.oppName} вышел из игры.', textAlign: TextAlign.center),
          const SizedBox(height: 8),
          OutlinedButton(onPressed: s.leave, child: const Text('В меню')),
        ],
      ),
    );
  }
}

// ======================= Обрыв связи =======================

class ClosedScreen extends StatelessWidget {
  final GameSession s;
  const ClosedScreen({super.key, required this.s});

  @override
  Widget build(BuildContext context) {
    final th = Theme.of(context);
    return Shell(
      child: Column(
        children: [
          const SizedBox(height: 60),
          Icon(Icons.wifi_off, size: 64, color: th.colorScheme.error),
          const SizedBox(height: 16),
          Text(s.closedReason ?? 'Соединение закрыто.',
              textAlign: TextAlign.center, style: th.textTheme.titleLarge),
          const SizedBox(height: 32),
          FilledButton(onPressed: s.leave, child: const Text('В меню')),
        ],
      ),
    );
  }
}
