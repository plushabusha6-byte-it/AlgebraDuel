import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:math';

import 'package:flutter/foundation.dart';
import 'package:wakelock_plus/wakelock_plus.dart';

import 'equations.dart';
import 'scratch.dart';

enum Phase { menu, waiting, connecting, ready, playing, roundResult, finished, closed }

class RoundOutcome {
  final String correct;
  final String myAnswer;
  final String oppAnswer;
  final bool myOk;
  final bool oppOk;
  final int myPts;
  final int oppPts;

  const RoundOutcome({
    required this.correct,
    required this.myAnswer,
    required this.oppAnswer,
    required this.myOk,
    required this.oppOk,
    required this.myPts,
    required this.oppPts,
  });
}

/// Запись о сыгранном раунде — для экрана «Разбор».
class RoundRecord {
  final int no;
  final String topic;
  final String text;
  final String correct;
  final List<String> steps;
  final String myAnswer;
  final bool myOk;
  final String oppAnswer;
  final bool oppOk;
  final int myPts;
  final int oppPts;
  final ScratchController pad;

  const RoundRecord({
    required this.no,
    required this.topic,
    required this.text,
    required this.correct,
    required this.steps,
    required this.myAnswer,
    required this.myOk,
    required this.oppAnswer,
    required this.oppOk,
    required this.myPts,
    required this.oppPts,
    required this.pad,
  });
}

/// Вся логика игры. Хост — главный: придумывает примеры, проверяет ответы,
/// считает очки. Второй телефон подключается по IP и только показывает состояние.
class GameSession extends ChangeNotifier {
  static const int port = 4040;

  Phase phase = Phase.menu;
  bool isHost = false;
  String myName = 'Игрок';
  String oppName = 'Соперник';
  String lastIp = '';
  String? error;
  String? closedReason;
  List<String> myIps = [];
  bool oppLeft = false;

  // Игра с ботом
  bool solo = false;
  int botSkill = 1; // 0 — новичок, 1 — средний, 2 — сильный
  static const List<String> botNames = ['Новичок', 'Средний', 'Сильный'];
  static const List<double> _botAcc = [0.55, 0.75, 0.9];
  static const List<double> _botLo = [0.55, 0.35, 0.2];
  static const List<double> _botHi = [0.9, 0.7, 0.5];

  // История раундов и черновик текущего раунда
  final List<RoundRecord> history = [];
  ScratchController pad = ScratchController();

  // Настройки (задаёт хост)
  int level = 0;
  int rounds = 5;
  int minutes = defaultMinutes[0];

  // Состояние игры
  int roundNo = 0;
  int totalRounds = 0;
  int totalSeconds = 0;
  int remaining = 0;
  int myScore = 0;
  int oppScore = 0;
  String curTopic = '';
  String curText = '';
  String curInstruction = '';
  bool iAnswered = false;
  bool oppAnswered = false;
  String? myAnswerShown;
  RoundOutcome? outcome;
  bool lastRound = false;

  // Подсказки
  int hintsUsed = 0;
  List<String> _roundHints = [];

  List<String> get hintsShown =>
      _roundHints.take(hintsUsed.clamp(0, _roundHints.length).toInt()).toList();

  int get hintsLeft {
    final total = _roundHints.length < hintsPerRound ? _roundHints.length : hintsPerRound;
    final left = total - hintsUsed;
    return left < 0 ? 0 : left;
  }

  // Служебное
  ServerSocket? _server;
  Socket? _sock;
  StreamSubscription<String>? _sub;
  Timer? _ticker;
  Task? _task;
  final Stopwatch _sw = Stopwatch();
  bool _hostAnswered = false;
  bool _clientAnswered = false;
  bool _hostOk = false;
  bool _clientOk = false;
  String? _hostText;
  String? _clientText;
  int _hostMs = 0;
  int _clientMs = 0;
  int _joinTok = 0;
  Timer? _botTimer;
  int _botDueMs = 0;
  bool _botPlanOk = true;
  Task? _botTask;
  List<String> _curSteps = [];
  final Random _rng = Random();

  // ---------- Настройки ----------

  void setLevel(int i) {
    level = i;
    minutes = defaultMinutes[i];
    notifyListeners();
  }

  void setRounds(int r) {
    rounds = r;
    notifyListeners();
  }

  void setMinutes(int m) {
    minutes = m;
    notifyListeners();
  }

  // ---------- Подключение ----------

  Future<void> hostGame(String name) async {
    _cleanup();
    _resetGameState();
    solo = false;
    myName = _cleanName(name);
    isHost = true;
    error = null;
    try {
      _server = await ServerSocket.bind(InternetAddress.anyIPv4, port, shared: true);
    } catch (e) {
      isHost = false;
      error = 'Не удалось создать игру: $e';
      notifyListeners();
      return;
    }
    _server!.listen(_onIncoming, onError: (_) {});
    phase = Phase.waiting;
    _keepAwake(true);
    notifyListeners();
    myIps = await _findIps();
    notifyListeners();
  }

  Future<void> joinGame(String name, String ip) async {
    _cleanup();
    _resetGameState();
    solo = false;
    myName = _cleanName(name);
    lastIp = ip.trim();
    isHost = false;
    error = null;
    phase = Phase.connecting;
    final tok = _joinTok;
    notifyListeners();
    try {
      final s = await Socket.connect(lastIp, port, timeout: const Duration(seconds: 6));
      if (tok != _joinTok) {
        // Игрок нажал «Выйти», пока шло подключение.
        s.destroy();
        return;
      }
      _attach(s);
      _send({'t': 'hello', 'name': myName});
      _keepAwake(true);
    } catch (_) {
      if (tok != _joinTok) return;
      _cleanup();
      phase = Phase.menu;
      error = 'Не удалось подключиться к $lastIp.\n'
          'Проверьте, что оба телефона в одной Wi-Fi сети, игра на втором телефоне '
          'уже создана и адрес введён верно.';
      notifyListeners();
    }
  }

  void leave() {
    _cleanup();
    _resetGameState();
    solo = false;
    isHost = false;
    error = null;
    closedReason = null;
    phase = Phase.menu;
    notifyListeners();
  }

  /// Игра в одиночку: соперник — бот, сеть не нужна.
  void hostSolo(String name) {
    _cleanup();
    _resetGameState();
    myName = _cleanName(name);
    isHost = true;
    solo = true;
    error = null;
    oppName = 'Бот';
    phase = Phase.ready;
    _keepAwake(true);
    notifyListeners();
  }

  void setBotSkill(int i) {
    botSkill = i.clamp(0, 2).toInt();
    notifyListeners();
  }

  void _onIncoming(Socket s) {
    final open = phase == Phase.waiting || phase == Phase.ready || phase == Phase.finished;
    if (_sock != null || !open) {
      s.destroy();
      return;
    }
    _attach(s);
  }

  void _attach(Socket s) {
    _sock = s;
    try {
      s.setOption(SocketOption.tcpNoDelay, true);
    } catch (_) {}
    s.done.catchError((_) {});
    _sub = s
        .cast<List<int>>()
        .transform(utf8.decoder)
        .transform(const LineSplitter())
        .listen(
          _onLine,
          onDone: () => _peerGone(s),
          onError: (_) => _peerGone(s),
          cancelOnError: true,
        );
  }

  void _peerGone(Socket s) {
    if (_sock != s) return;
    _sub?.cancel();
    _sub = null;
    _sock?.destroy();
    _sock = null;

    if (isHost && (phase == Phase.waiting || phase == Phase.ready)) {
      phase = Phase.waiting;
      oppName = 'Соперник';
      notifyListeners();
      return;
    }
    if (phase == Phase.menu || phase == Phase.closed) return;
    if (phase == Phase.finished) {
      oppLeft = true;
      notifyListeners();
      return;
    }
    _ticker?.cancel();
    _ticker = null;
    closedReason = 'Связь с соперником потеряна.';
    phase = Phase.closed;
    _keepAwake(false);
    notifyListeners();
  }

  void _send(Map<String, Object?> m) {
    final s = _sock;
    if (s == null) return;
    try {
      s.write('${jsonEncode(m)}\n');
    } catch (_) {}
  }

  void _onLine(String line) {
    Map<String, dynamic> m;
    try {
      m = jsonDecode(line) as Map<String, dynamic>;
    } catch (_) {
      return;
    }
    final t = m['t'];
    if (t is! String) return;
    if (isHost) {
      _hostRecv(t, m);
    } else {
      _clientRecv(t, m);
    }
  }

  // ---------- Хост: приём сообщений ----------

  void _hostRecv(String t, Map<String, dynamic> m) {
    if (t == 'hello') {
      oppName = _cleanName('${m['name'] ?? ''}', fallback: 'Соперник');
      if (phase == Phase.waiting) phase = Phase.ready;
      _send({'t': 'welcome', 'host': myName});
      notifyListeners();
    } else if (t == 'answer') {
      _onClientAnswer(m);
    }
  }

  void _onClientAnswer(Map<String, dynamic> m) {
    if (phase != Phase.playing || _clientAnswered) return;
    if (m['n'] != roundNo) return;
    final text = '${m['text'] ?? ''}'.trim();
    final parsed = parseAnswer(text);
    _clientAnswered = true;
    _clientText = text;
    _clientOk = parsed != null && _task != null && isCorrect(_task!, parsed);
    _clientMs = _sw.elapsedMilliseconds;
    oppAnswered = true;
    notifyListeners();
    _maybeEnd();
  }

  // ---------- Клиент: приём сообщений ----------

  void _clientRecv(String t, Map<String, dynamic> m) {
    switch (t) {
      case 'welcome':
        oppName = _cleanName('${m['host'] ?? ''}', fallback: 'Соперник');
        phase = Phase.ready;
        notifyListeners();
        break;
      case 'start':
        totalRounds = _int(m['rounds']);
        totalSeconds = _int(m['seconds']);
        level = _int(m['level']).clamp(0, 3).toInt();
        _resetScores();
        notifyListeners();
        break;
      case 'round':
        roundNo = _int(m['n']);
        totalRounds = _int(m['total']);
        totalSeconds = _int(m['sec']);
        curTopic = '${m['topic'] ?? ''}';
        curText = '${m['text'] ?? ''}';
        curInstruction = '${m['ins'] ?? ''}';
        final hs = m['hints'];
        _roundHints = hs is List ? hs.map((e) => '$e').toList() : <String>[];
        hintsUsed = 0;
        pad = ScratchController();
        iAnswered = false;
        oppAnswered = false;
        myAnswerShown = null;
        outcome = null;
        remaining = totalSeconds;
        phase = Phase.playing;
        _ticker?.cancel();
        _ticker = Timer.periodic(const Duration(seconds: 1), (_) {
          if (remaining > 0) remaining--;
          notifyListeners();
        });
        notifyListeners();
        break;
      case 'opp':
        oppAnswered = true;
        notifyListeners();
        break;
      case 'result':
        _ticker?.cancel();
        _ticker = null;
        outcome = RoundOutcome(
          correct: '${m['correct'] ?? ''}',
          myAnswer: '${m['c'] ?? '—'}',
          oppAnswer: '${m['h'] ?? '—'}',
          myOk: m['cok'] == true,
          oppOk: m['hok'] == true,
          myPts: _int(m['cp']),
          oppPts: _int(m['hp']),
        );
        myScore = _int(m['cs']);
        oppScore = _int(m['hs']);
        lastRound = m['last'] == true;
        final st = m['steps'];
        _addRecord(st is List ? st.map((e) => '$e').toList() : <String>[]);
        phase = Phase.roundResult;
        notifyListeners();
        break;
      case 'end':
        _ticker?.cancel();
        _ticker = null;
        phase = Phase.finished;
        notifyListeners();
        break;
      case 'lobby':
        _resetScores();
        phase = Phase.ready;
        notifyListeners();
        break;
    }
  }

  // ---------- Ход игры (хост) ----------

  void startGame() {
    if (!isHost || phase != Phase.ready) return;
    _resetScores();
    totalRounds = rounds;
    totalSeconds = minutes * 60;
    _send({'t': 'start', 'rounds': totalRounds, 'seconds': totalSeconds, 'level': level});
    _nextRound();
  }

  void _nextRound() {
    roundNo++;
    final task = generateTask(level);
    _task = task;
    _hostAnswered = false;
    _clientAnswered = false;
    _hostOk = false;
    _clientOk = false;
    _hostText = null;
    _clientText = null;
    iAnswered = false;
    oppAnswered = false;
    myAnswerShown = null;
    outcome = null;
    _roundHints = task.hints;
    hintsUsed = 0;
    pad = ScratchController();
    _curSteps = task.steps;
    _scheduleBot(task);
    curTopic = task.topic;
    curText = task.text;
    curInstruction = task.instruction;
    remaining = totalSeconds;
    phase = Phase.playing;
    _sw
      ..reset()
      ..start();
    _send({
      't': 'round',
      'n': roundNo,
      'total': totalRounds,
      'topic': curTopic,
      'text': curText,
      'ins': curInstruction,
      'sec': totalSeconds,
      'hints': task.hints,
    });
    _ticker?.cancel();
    _ticker = Timer.periodic(const Duration(seconds: 1), (_) {
      remaining--;
      if (remaining <= 0) {
        remaining = 0;
        _endRound();
      } else {
        notifyListeners();
      }
    });
    notifyListeners();
  }

  /// Открыть следующую подсказку (у каждого игрока — свои, 2 на пример).
  void useHint() {
    if (phase != Phase.playing || iAnswered || hintsLeft <= 0) return;
    hintsUsed++;
    notifyListeners();
  }

  /// Отправить ответ. Возвращает текст ошибки или null, если всё хорошо.
  String? submit(String text) {
    if (phase != Phase.playing || iAnswered) return null;
    final clean = text.trim();
    final parsed = parseAnswer(clean);
    if (parsed == null) {
      return 'Не понял ответ. Примеры: 3   или   -2 5   или   1/2';
    }
    iAnswered = true;
    myAnswerShown = clean;
    if (isHost) {
      _hostAnswered = true;
      _hostText = clean;
      _hostOk = _task != null && isCorrect(_task!, parsed);
      _hostMs = _sw.elapsedMilliseconds;
      _send({'t': 'opp'});
      // Бот не заставляет ждать: если человек ответил раньше, бот «отвечает» сразу
      // с запланированным результатом, а бонус за скорость достаётся человеку.
      if (solo && !_clientAnswered && _botTask != null) {
        _botTimer?.cancel();
        _botTimer = null;
        _clientAnswered = true;
        _clientOk = _botPlanOk;
        _clientText = _botPlanOk ? _botTask!.answerText : wrongAnswerFor(_botTask!);
        _clientMs = max(_botDueMs, _hostMs + 1);
        oppAnswered = true;
      }
      notifyListeners();
      _maybeEnd();
    } else {
      _send({'t': 'answer', 'n': roundNo, 'text': clean});
      notifyListeners();
    }
    return null;
  }

  void _maybeEnd() {
    if (_hostAnswered && _clientAnswered) _endRound();
  }

  void _endRound() {
    if (phase != Phase.playing) return;
    _ticker?.cancel();
    _ticker = null;

    var hp = 0;
    var cp = 0;
    if (_hostOk) hp += 1;
    if (_clientOk) cp += 1;
    // Бонус +1 тому, кто первым ответил верно.
    if (_hostOk && _clientOk) {
      if (_hostMs <= _clientMs) {
        hp += 1;
      } else {
        cp += 1;
      }
    } else if (_hostOk) {
      hp += 1;
    } else if (_clientOk) {
      cp += 1;
    }
    myScore += hp;
    oppScore += cp;

    final correct = _task?.answerText ?? '';
    outcome = RoundOutcome(
      correct: correct,
      myAnswer: _hostText ?? '—',
      oppAnswer: _clientText ?? '—',
      myOk: _hostOk,
      oppOk: _clientOk,
      myPts: hp,
      oppPts: cp,
    );
    lastRound = roundNo >= totalRounds;
    _botTimer?.cancel();
    _botTimer = null;
    _addRecord(_curSteps);
    phase = Phase.roundResult;
    _send({
      't': 'result',
      'correct': correct,
      'h': _hostText ?? '—',
      'c': _clientText ?? '—',
      'hok': _hostOk,
      'cok': _clientOk,
      'hp': hp,
      'cp': cp,
      'hs': myScore,
      'cs': oppScore,
      'last': lastRound,
      'steps': _curSteps,
    });
    notifyListeners();
  }

  /// Хост: следующий раунд или итоги.
  void proceed() {
    if (!isHost || phase != Phase.roundResult) return;
    if (lastRound) {
      phase = Phase.finished;
      _send({'t': 'end'});
      notifyListeners();
    } else {
      _nextRound();
    }
  }

  /// Хост: вернуться к настройкам для новой партии.
  void backToLobby() {
    if (!isHost) return;
    _resetScores();
    phase = (_sock != null || solo) ? Phase.ready : Phase.waiting;
    oppLeft = false;
    _send({'t': 'lobby'});
    notifyListeners();
  }

  // ---------- История и бот ----------

  void _addRecord(List<String> steps) {
    final o = outcome;
    if (o == null) return;
    history.add(RoundRecord(
      no: roundNo,
      topic: curTopic,
      text: curText,
      correct: o.correct,
      steps: steps,
      myAnswer: o.myAnswer,
      myOk: o.myOk,
      oppAnswer: o.oppAnswer,
      oppOk: o.oppOk,
      myPts: o.myPts,
      oppPts: o.oppPts,
      pad: pad,
    ));
  }

  void _scheduleBot(Task task) {
    _botTimer?.cancel();
    _botTimer = null;
    if (!solo) return;
    final lo = _botLo[botSkill];
    final hi = _botHi[botSkill];
    var secs = (totalSeconds * (lo + _rng.nextDouble() * (hi - lo))).round();
    if (secs < 4) secs = 4;
    final maxS = totalSeconds - 2;
    if (secs > maxS) secs = maxS < 1 ? 1 : maxS;
    final ok = _rng.nextDouble() < _botAcc[botSkill];
    _botTask = task;
    _botPlanOk = ok;
    _botDueMs = secs * 1000;
    _botTimer = Timer(Duration(seconds: secs), () => _botAnswer(task, ok));
  }

  void _botAnswer(Task task, bool ok) {
    if (phase != Phase.playing || _clientAnswered) return;
    _clientAnswered = true;
    _clientText = ok ? task.answerText : wrongAnswerFor(task);
    _clientOk = ok;
    _clientMs = _sw.elapsedMilliseconds;
    oppAnswered = true;
    notifyListeners();
    _maybeEnd();
  }

  // ---------- Вспомогательное ----------

  void _resetScores() {
    roundNo = 0;
    myScore = 0;
    oppScore = 0;
    iAnswered = false;
    oppAnswered = false;
    myAnswerShown = null;
    outcome = null;
    lastRound = false;
    oppLeft = false;
    hintsUsed = 0;
    _roundHints = [];
    history.clear();
    _botTimer?.cancel();
    _botTimer = null;
  }

  void _resetGameState() {
    _resetScores();
    totalRounds = 0;
    totalSeconds = 0;
    remaining = 0;
    oppName = 'Соперник';
    myIps = [];
    curTopic = '';
    curText = '';
    curInstruction = '';
  }

  void _cleanup() {
    _joinTok++;
    _botTimer?.cancel();
    _botTimer = null;
    _ticker?.cancel();
    _ticker = null;
    _sub?.cancel();
    _sub = null;
    _sock?.destroy();
    _sock = null;
    _server?.close();
    _server = null;
    _task = null;
    _keepAwake(false);
  }

  void _keepAwake(bool on) {
    try {
      if (on) {
        WakelockPlus.enable().catchError((_) {});
      } else {
        WakelockPlus.disable().catchError((_) {});
      }
    } catch (_) {}
  }

  int _int(Object? v) => v is num ? v.toInt() : 0;

  String _cleanName(String s, {String fallback = 'Игрок'}) {
    final t = s.trim();
    if (t.isEmpty) return fallback;
    return t.length > 16 ? t.substring(0, 16) : t;
  }

  Future<List<String>> _findIps() async {
    try {
      final ifs = await NetworkInterface.list(
        type: InternetAddressType.IPv4,
        includeLoopback: false,
      );
      final all = <String>[];
      for (final i in ifs) {
        for (final a in i.addresses) {
          all.add(a.address);
        }
      }
      all.sort((a, b) => _rank(a).compareTo(_rank(b)));
      return all;
    } catch (_) {
      return [];
    }
  }

  int _rank(String ip) {
    if (ip.startsWith('192.168.')) return 0;
    if (ip.startsWith('10.')) return 1;
    if (RegExp(r'^172\.(1[6-9]|2\d|3[01])\.').hasMatch(ip)) return 2;
    return 3;
  }

  @override
  void dispose() {
    _cleanup();
    super.dispose();
  }
}
