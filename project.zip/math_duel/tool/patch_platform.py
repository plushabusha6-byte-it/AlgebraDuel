#!/usr/bin/env python3
"""Донастраивает папки android/ios, которые создаёт `flutter create`:
разрешения на сеть, название приложения, доступ к локальной сети на iPhone."""
import pathlib
import plistlib
import re
import sys

NAME = "Матем-дуэль"


def install_icons(platform):
    """Подменяет стандартные иконки Flutter на нашу (картинки лежат в tool/icons)."""
    import shutil
    here = pathlib.Path(__file__).resolve().parent / "icons"
    done = 0
    if platform == "android":
        sizes = {"mdpi": 48, "hdpi": 72, "xhdpi": 96, "xxhdpi": 144, "xxxhdpi": 192}
        for dpi, px in sizes.items():
            dst = pathlib.Path(f"android/app/src/main/res/mipmap-{dpi}/ic_launcher.png")
            if dst.parent.is_dir():
                shutil.copyfile(here / f"{px}.png", dst)
                done += 1
    else:
        base = pathlib.Path("ios/Runner/Assets.xcassets/AppIcon.appiconset")
        names = {
            "20x20@1x": 20, "20x20@2x": 40, "20x20@3x": 60,
            "29x29@1x": 29, "29x29@2x": 58, "29x29@3x": 87,
            "40x40@1x": 40, "40x40@2x": 80, "40x40@3x": 120,
            "60x60@2x": 120, "60x60@3x": 180,
            "76x76@1x": 76, "76x76@2x": 152,
            "83.5x83.5@2x": 167, "1024x1024@1x": 1024,
        }
        for name, px in names.items():
            dst = base / f"Icon-App-{name}.png"
            if dst.exists():
                shutil.copyfile(here / f"{px}.png", dst)
                done += 1
    print(f"icons installed for {platform}: {done} files")

platform = sys.argv[1] if len(sys.argv) > 1 else ""

if platform == "android":
    p = pathlib.Path("android/app/src/main/AndroidManifest.xml")
    s = p.read_text(encoding="utf-8")
    perms = [
        "android.permission.INTERNET",
        "android.permission.ACCESS_NETWORK_STATE",
        "android.permission.ACCESS_WIFI_STATE",
    ]
    add = "".join(
        f'<uses-permission android:name="{x}"/>\n    ' for x in perms if x not in s
    )
    if "<application" not in s:
        sys.exit("AndroidManifest.xml: не найден тег <application>")
    s = s.replace("<application", add + "<application", 1)
    s = re.sub(r'android:label="[^"]*"', f'android:label="{NAME}"', s, count=1)
    p.write_text(s, encoding="utf-8")
    print("Android manifest patched")
    try:
        install_icons("android")
    except Exception as e:  # иконка не должна ломать сборку
        print("icon step skipped:", e)

elif platform == "ios":
    p = pathlib.Path("ios/Runner/Info.plist")
    with p.open("rb") as f:
        d = plistlib.load(f)
    d["NSLocalNetworkUsageDescription"] = "Нужно, чтобы играть с другом по Wi-Fi."
    d["CFBundleDisplayName"] = NAME
    with p.open("wb") as f:
        plistlib.dump(d, f)
    print("iOS Info.plist patched")
    try:
        install_icons("ios")
    except Exception as e:
        print("icon step skipped:", e)

else:
    sys.exit("usage: patch_platform.py android|ios")
