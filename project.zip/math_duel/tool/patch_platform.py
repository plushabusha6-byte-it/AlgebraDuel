#!/usr/bin/env python3
"""Донастраивает папки android/ios, которые создаёт `flutter create`:
разрешения на сеть, название приложения, доступ к локальной сети на iPhone."""
import pathlib
import plistlib
import re
import sys

NAME = "Матем-дуэль"
platform = sys.argv[1] if len(sys.argv) > 1 else ""

if platform == "android":
    p = pathlib.Path("android/app/src/main/AndroidManifest.xml")
    s = p.read_text(encoding="utf-8")
    perms = [
        "android.permission.INTERNET",
        "android.permission.ACCESS_NETWORK_STATE",
        "android.permission.ACCESS_WIFI_STATE",
    ]
    add = "".join(
        f'<uses-permission android:name="{x}"/>\n    ' for x in perms if x not in s
    )
    if "<application" not in s:
        sys.exit("AndroidManifest.xml: не найден тег <application>")
    s = s.replace("<application", add + "<application", 1)
    s = re.sub(r'android:label="[^"]*"', f'android:label="{NAME}"', s, count=1)
    p.write_text(s, encoding="utf-8")
    print("Android manifest patched")

elif platform == "ios":
    p = pathlib.Path("ios/Runner/Info.plist")
    with p.open("rb") as f:
        d = plistlib.load(f)
    d["NSLocalNetworkUsageDescription"] = "Нужно, чтобы играть с другом по Wi-Fi."
    d["CFBundleDisplayName"] = NAME
    with p.open("wb") as f:
        plistlib.dump(d, f)
    print("iOS Info.plist patched")

else:
    sys.exit("usage: patch_platform.py android|ios")
